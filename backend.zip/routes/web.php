<?php

use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::view('/','user.index')->name('user.index');



Route::prefix('admin')->group(callback: function () {
    Route::view('/', 'admin.login')->name("admin.login");
    Route::post('/auth', [AdminController::class,'auth'])->name('admin.auth');

    Route::middleware(['adminAuth'])->group(function () {
        Route::get('logout', [AdminController::class, 'logout'])->name('admin.logout');
        Route::view('profile','admin.profile')->name('admin.profile');
        Route::post('profile',[AdminController::class, 'update_password'])->name('admin.password.update');

        Route::get('section/{id}', [AdminController::class, 'section'])->name('admin.view.section');

        Route::get('projects', [AdminController::class, 'projects'])->name('admin.view.projects');
        Route::post('add-project', [AdminController::class, 'add_successfull_project'])->name('admin.add.project');
        Route::delete('delete-project', [AdminController::class, 'delete_successfull_project'])->name('admin.delete.project');
    });
});
