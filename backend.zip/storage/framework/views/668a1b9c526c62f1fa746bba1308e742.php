
<!DOCTYPE html>
<html data-wf-page="62d564959d641a74cf38ccca" data-wf-site="62d564959d641af74838ccc9" data-wf-status="1" class="w-mod-js wf-urbanist-n4-active wf-urbanist-n5-active wf-urbanist-n6-active wf-urbanist-n7-active wf-urbanist-n8-active wf-urbanist-n9-active wf-active w-mod-ix">
<head>
    <meta charset="utf-8">
    <title>GoldApps.uz</title>
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
          integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <script src="../js/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">WebFont.load({google: {families: ["Urbanist:regular,500,600,700,800,900"]}});</script>
    <script type="text/javascript">!function (o, c) {
            var n = c.documentElement, t = " w-mod-";
            n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch")
        }(window, document);</script>
    <link href="images/goldapps.png" rel="">
</head>
<body class="body">
<div id="scroll-to-top" class="scroll-to-top---anchor-div scroll-to-top-anchor"></div>
<div class="fixed-navbar-wrapper">
    <div data-w-id="2f3c782d-5710-69dc-6e13-17b01a597038" data-animation="over-right" data-collapse="medium"
         data-duration="400" data-easing="ease" data-easing2="ease" role="banner" class="navbar w-nav">
        <div class="menu-open-overlay"></div>
        <div class="navbar-container">
            <img src="images/goldapps.png" loading="lazy" alt="Logo" class="log-image">
            <div class="nav-menu-inner">
                <a href="#" class="nav-menu-logo w-inline-block">
                    <div class="nav-links-wrapper" style="font-family: Arial, sans-serif">
                        <a href="#Top" class="nav-link w-nav-link">Bosh sahifa</a>
                        <a href="#why-seo" class="nav-link w-nav-link">Nima uchun biz?</a>
                        <a href="#Sevices" class="nav-link w-nav-link">Xizmatlarimiz</a>
                        <a href="#Team" class="nav-link w-nav-link">Jamoamiz</a>
                        <a href="#Pricing" class="nav-link w-nav-link">Narxlar</a>
                        <a href="#Blog" class="nav-link w-nav-link">Yangiliklar</a>
                    </div>
                    <div class="contact-us-button-wrapper">
                        <a href="#" class="primary-btn w-button">Aloqaga chiqing!</a>
                    </div>
                </a>
            </div>
            <div class="enquire-btn-wrapper">
                <a href="#" class="nav-btn w-button">Bog'lanish</a>
            </div>
            <div class="menu-button w-nav-button">
                <div class="menu-animation">
                    <div class="top-line black-background"></div>
                    <div class="middle-line black-background"></div>
                    <div class="middle-line-45 black-background"></div>
                    <div class="middle-line--45 black-background"></div>
                    <div class="bottom-line black-background"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<section id="Home" class="hero-section">
    <div class="main-container w-container">
        <div class="home-content-wrapper">
            <div id="Navbar" class="top-bar-wrapper">
                <div class="top-bar-contact-wrapper">
                    <div class="top-bar-contact-div">
                        <div class="top-bar-contact-icon-div">
                            <img src="images/62d93468f6774d402b44d2d5_Phone%20icon.svg" loading="lazy" alt=""
                                 class="top-bar-icon">
                        </div>
                        <a href="tel:+998910248024" target="_blank" class="top-bar-contact-link w-inline-block">
                            <div class="paragraph-v-2">+998(91) 024 80 24</div>
                        </a>
                    </div>
                    <div class="top-bar-contact-div">
                        <div class="top-bar-contact-icon-div">
                            <img src="images/62d93467f6774d247c44d2d1_Mail%20icon.svg" loading="lazy" alt=""
                                 class="top-bar-icon"></div>
                        <a href="mailto:goldapps2022@gmail.com" class="top-bar-contact-link w-inline-block">
                            <div class="paragraph-v-2">goldapps2022@gmail.com</div>
                        </a>
                    </div>
                </div>
                <div class="topbar-social-wrapper">
                    <a href="#" class="topbar-social-div fb w-inline-block">
                        <div class="header-embed w-embed">
                            <i class="fa-brands fa-telegram"></i>
                        </div>
                    </a>
                    <a href="#" class="topbar-social-div twitter w-inline-block">
                        <div class="header-embed w-embed">
                            <svg width="19" height="17" viewBox="0 0 19 17" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                      d="M18.1126 4.99546C18.0977 4.29032 17.9567 3.59267 17.6956 2.9322C17.4703 2.36502 17.1171 1.85123 16.6607 1.42664C16.2125 0.99424 15.6702 0.659657 15.0715 0.446222C14.3743 0.198845 13.6379 0.065255 12.8936 0.0511322C11.9366 0.00980333 11.6311 0 9.19439 0C6.75766 0 6.45215 0.00980333 5.49515 0.0511322C4.75084 0.065255 4.01444 0.198845 3.31727 0.446222C2.71858 0.659657 2.17624 0.99424 1.72807 1.42664C1.27164 1.85123 0.918473 2.36502 0.69318 2.9322C0.43206 3.59267 0.291048 4.29032 0.276141 4.99546C0.232516 5.90209 0.222168 6.19152 0.222168 8.5C0.222168 10.8085 0.232516 11.0979 0.276141 12.0045C0.291048 12.7097 0.43206 13.4073 0.69318 14.0678C0.918473 14.635 1.27164 15.1488 1.72807 15.5734C2.17622 16.0058 2.71857 16.3404 3.31727 16.5538C4.01444 16.8012 4.75084 16.9347 5.49515 16.9489C6.45215 16.9903 6.75766 17 9.19439 17C11.6311 17 11.9366 16.9903 12.8936 16.9489C13.6379 16.9347 14.3743 16.8012 15.0715 16.5538C16.2767 16.1122 17.2295 15.2096 17.6956 14.0678C17.9567 13.4073 18.0977 12.7097 18.1126 12.0045C18.1563 11.0979 18.1666 10.8085 18.1666 8.5C18.1666 6.19152 18.1563 5.90209 18.1126 4.99546ZM16.4977 11.9347C16.491 12.4737 16.3865 13.0076 16.1887 13.513C15.8869 14.2543 15.2684 14.8402 14.4859 15.1262C13.9524 15.3135 13.3889 15.4125 12.8199 15.4189C11.874 15.4597 11.5902 15.4684 9.19438 15.4684C6.79854 15.4684 6.51481 15.4597 5.56883 15.4189C4.9999 15.4125 4.43636 15.3135 3.90285 15.1262C3.51312 14.9899 3.16059 14.7727 2.87119 14.4903C2.57318 14.2162 2.34384 13.8822 2.20004 13.513C2.00231 13.0076 1.89779 12.4737 1.89105 11.9347C1.84793 11.0384 1.8388 10.7696 1.8388 8.49995C1.8388 6.23031 1.84793 5.96152 1.89106 5.06521C1.8978 4.52622 2.00232 3.99234 2.20004 3.48691C2.34384 3.1177 2.57317 2.78372 2.87118 2.50955C3.16059 2.22723 3.51312 2.00995 3.90285 1.87372C4.43636 1.6864 4.9999 1.58739 5.56883 1.581C6.51494 1.54015 6.79866 1.53149 9.19438 1.53149C11.5901 1.53149 11.8738 1.54015 12.8199 1.58101C13.3889 1.5874 13.9524 1.68641 14.4859 1.87373C14.8756 2.00996 15.2282 2.22723 15.5176 2.50955C15.8156 2.78372 16.0449 3.1177 16.1887 3.48691C16.3865 3.99234 16.491 4.52622 16.4977 5.06521C16.5408 5.96149 16.55 6.23037 16.55 8.49995C16.55 10.7695 16.5408 11.0384 16.4977 11.9347ZM4.587 8.50006C4.587 6.0894 6.6498 4.13517 9.19438 4.13517C11.739 4.1352 13.8017 6.08941 13.8018 8.50006C13.8018 10.9107 11.739 12.8649 9.19438 12.8649C6.6498 12.8649 4.587 10.9107 4.587 8.50006ZM9.19438 11.3333C7.54264 11.3333 6.20364 10.0648 6.20364 8.5C6.20364 6.93519 7.54264 5.66667 9.19438 5.66667C10.8461 5.66667 12.1851 6.93519 12.1851 8.5C12.1851 9.25145 11.87 9.97212 11.3092 10.5035C10.7483 11.0348 9.98757 11.3333 9.19438 11.3333ZM13.9838 4.98263C14.5784 4.98263 15.0604 4.52596 15.0604 3.96263C15.0604 3.3993 14.5784 2.94263 13.9838 2.94263C13.3891 2.94263 12.9071 3.3993 12.9071 3.96263C12.9071 4.52596 13.3891 4.98263 13.9838 4.98263Z"
                                      fill="currentColor"></path>
                            </svg>
                        </div>
                    </a>
                    <a href="#" class="topbar-social-div twitter w-inline-block">
                        <div class="header-embed w-embed">
                            <svg width="100%" height="100%" viewBox="0 0 18 15" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path d="M16.0429 4.00985C16.0505 4.16285 16.0533 4.31774 16.0533 4.47074C16.0533 9.18352 12.4672 14.616 5.90996 14.616C3.89546 14.616 2.02262 14.0257 0.444458 13.0132C0.724014 13.0463 1.00735 13.0633 1.29446 13.0633C2.96612 13.0633 4.50274 12.4929 5.72201 11.538C4.16274 11.5087 2.84524 10.4793 2.3919 9.06263C2.60912 9.10324 2.83296 9.12496 3.06246 9.12496C3.38829 9.12496 3.70374 9.08246 4.00218 9.00124C2.37112 8.67257 1.1424 7.2323 1.1424 5.50396C1.1424 5.48885 1.1424 5.47468 1.1424 5.45957C1.62312 5.72685 2.17374 5.88741 2.7574 5.9063C1.80068 5.26596 1.17074 4.17607 1.17074 2.93791C1.17074 2.2853 1.3464 1.67235 1.65429 1.14535C3.4119 3.30341 6.04029 4.72196 9.00301 4.87118C8.94257 4.60957 8.9114 4.33852 8.9114 4.05802C8.9114 2.0898 10.5066 0.494629 12.4757 0.494629C13.5014 0.494629 14.4279 0.92624 15.0786 1.61946C15.8899 1.45891 16.653 1.16235 17.3425 0.754351C17.0761 1.58641 16.5104 2.2853 15.7747 2.72635C16.4962 2.63946 17.1819 2.44963 17.8222 2.16535C17.3443 2.88124 16.7399 3.50835 16.0429 4.00985Z"
                                      fill="currentColor"></path>
                            </svg>
                        </div>
                    </a>
                </div>
            </div>
            <div class="navbar-wrapper">
                <div data-w-id="2f3c782d-5710-69dc-6e13-17b01a597038" data-animation="over-right" data-collapse="medium"
                     data-duration="400" data-easing="ease" data-easing2="ease" role="banner" class="navbar w-nav">
                    <div class="menu-open-overlay"></div>
                    <div class="navbar-container">
                        <a href="/" aria-current="page" class="brand w-nav-brand w--current">
                            <img src="images/goldapps.png" loading="lazy" alt="Logo" class="log-image">
                        </a>
                        <nav role="navigation" class="nav-menu w-nav-menu">
                            <div class="nav-menu-inner">
                                <a href="#" class="nav-menu-logo w-inline-block">
                                    <img src="images/62de9a2856c3b5d9cf9b4be5_Logo.svg" loading="lazy" alt="Logo"
                                         class="log-image">
                                </a>
                                <div class="nav-links-wrapper " style="font-family: Arial, sans-serif">
                                    <a href="#Top" class="nav-link w-nav-link">Bosh sahifa</a>
                                    <a href="#why-seo" class="nav-link w-nav-link">Nima uchun GoldApps?</a>
                                    <a href="#Sevices" class="nav-link w-nav-link">Xizmatlarimiz</a>
                                    <a href="#Team" class="nav-link w-nav-link">Jamoamiz</a>
                                    <a href="#Pricing" class="nav-link w-nav-link">Narxlar</a>
                                </div>
                                <div class="contact-us-button-wrapper">
                                    <a href="#" class="primary-btn w-button">Bog'lanish</a>
                                </div>
                            </div>
                        </nav>
                        <div class="enquire-btn-wrapper">
                            <a href="#Contact" class="nav-btn w-button">Bog'lanish</a></div>
                        <div class="menu-button w-nav-button">
                            <div class="menu-animation">
                                <div class="top-line black-background"></div>
                                <div class="middle-line black-background"></div>
                                <div class="middle-line-45 black-background"></div>
                                <div class="middle-line--45 black-background"></div>
                                <div class="bottom-line black-background"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hero-wrapper">
                <div class="hero-flexbox">
                    <div class="home-hero-flex-left">
                        <div class="hero-heading">
                            <h3 class="h1 _600-bold">GoldApps LLC sizning biznesingiz uchun</h3>
                            <div data-w-id="41e7d331-3a5a-cde3-b06b-8da5f7311c93" class="animated-words-wrapper">
                                <div style="-webkit-transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0); color: #ffbf00"
                                     class="word-1">Mobil ilova
                                </div>
                                <div style="-webkit-transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0); color: #ffbf00"
                                     class="word-2">Web sayt
                                </div>
                                <div style="-webkit-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0); color: #ffbf00"
                                     class="word-3">CRM va ERP tizim
                                </div>
                                <div style="-webkit-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0); color: #ffbf00"
                                     class="word-4">UI&UX Dizayn
                                </div>
                                <div style="-webkit-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0); color: #ffbf00"
                                     class="word-4">Avtomatlashtirish
                                </div>
                                <div style="-webkit-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, -72px, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0); color: #ffbf00"
                                     class="word-4">Telegram bot
                                </div>
                            </div>
                            <h3 class="h1 _600-bold">tayyorlab beradi!</h3>
                        </div>
                        <div class="btn-div">
                            <a href="#Contact" class="primary-btn hover-white w-button">Bog'lanish</a>
                        </div>
                    </div>
                    <div class="hero-flex-right">
                        <div class="hero-image-wrapper">
                            <!--                            <img src="images/62d93d7549c01267eac6bb06_hero%20image.svg"-->
                            <!--                                                             loading="lazy" alt="Girl working on Laptop"-->
                            <!--                                                             class="hero-image">-->
                            <div class="hero-image">
                                <img src="images/planning4.png">
                            </div>

                            <!--                            <div class="leads-increase">-->
                            <!--                                <div class="leads-increase-text-wrapper">-->
                            <!--                                    <figure class="leads-increase-icon-wrapper"><img-->
                            <!--                                            src="images/62d946de4fd9dfc7d52039e5_simple-up.svg" loading="lazy"-->
                            <!--                                            alt="Up arrow" class="leads-increase-icon"></figure>-->
                            <!--                                    <div class="leads-increase-text">200%</div>-->
                            <!--                                    <div>More Leads</div>-->
                            <!--                                </div>-->
                            <!--                                <div data-w-id="52018bcd-1840-eebc-e5d2-652b2124e6da"-->
                            <!--                                     style="-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0deg) skew(0, 0)"-->
                            <!--                                     class="leads-increase-circle"></div>-->
                            <!--                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-circles"></div>
    <div class="bg-circles-small"></div>
</section>
<section class="about-section">
    <div class="company-logo-container">
        <div class="company-logo-wrapper">
            <div class="gradient right"></div>
            <div class="gradient"></div>
            <div data-w-id="6ee31941-cd11-eadc-5a8f-c363c7ccd4dd" class="company-logo-images">
                <div style="-webkit-transform:translate3d(0%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0%, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);"
                     class="company-logo-row">
                    <figure class="client-image-wrapper"><img src="images/tozahavouz.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/yagona_travel.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/doridarmon.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/mytok.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/richboss.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/ideallogo.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/idealquiz.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/evakuator.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/qiziqarlionatili.png"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/ipeksuv.jpg"
                                                              loading="lazy" alt="logo" class="client-image"></figure>
                    <figure class="client-image-wrapper"><img src="images/webdizaynuz.png" loading="lazy" alt="logo"
                                                              class="client-image"></figure>
                </div>
            </div>
        </div>
    </div>
    <div class="main-container w-container">
        <div class="about-content-wrapper">
            <div data-w-id="559d9c00-1bd9-8798-8fbe-31d77ed228bc" style="opacity:0" class="about-flex-box">
                <div class="about-flex-left">
                    <div class="about-heading">
                        <h2 class="h2 _600-bold">Hamyonbob va sifatli raqamli mahsulotlar hamda biznes yechimlar</h2>
                    </div>
                </div>
                <div class="about-flex-right">
                    <div class="about-para">
                        <div class="paragraph-v-1 _500-medium">GoldApps LLC jamoasi sigabir vaqtning
                            o'zida 3 unikal funksionalni o'z ichiga oladigan hizmatlarni taklif etadi!
                            <ul>
                                <li>
                                    Hamyonbob
                                </li>
                                <li>
                                    Tez
                                </li>
                                <li>
                                    Sifatli
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="feature-row-1">
                <div data-current="Create your Invoice easily" data-easing="ease" data-duration-in="300"
                     data-duration-out="100" class="tabs-2 w-tabs">
                    <div class="tab-content-2 w-tab-content">
                        <div data-w-tab="Create your Invoice easily" class="tab-panel-2 w-tab-pane w--tab-active">
                            <div class="tab-wrapper hide-element-for-mob">
                                <figure class="feature-tab-left-image feature-image-wrapper">
                                    <div class="feature-animated-image-wrapper">
                                        <div class="feature-animated-image">
                                            <img alt="Tab Image 1" loading="lazy" src="images/illustration-1.png"
                                                 class="feature-tab-image"></div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                        <div data-w-tab="Send a payment request and get paid"
                             class="tab-panel-2 hide-element-on-mob w-tab-pane">
                            <div class="tab-wrapper hide-element-for-mob">
                                <figure class="feature-tab-left-image">
                                    <div class="feature-animated-image-wrapper">
                                        <div class="feature-animated-image"><img alt="Image 2" loading="lazy"
                                                                                 src="images/62daab9565feed09a03fe17e_tab%20image%202.svg"
                                                                                 class="feature-tab-image"></div>
                                    </div>
                                </figure>
                                <div class="feature-tab-text-wrapper"></div>
                            </div>
                        </div>
                        <div data-w-tab="Invoice template system" class="tab-panel-2 hide-element-on-mob w-tab-pane">
                            <div class="tab-wrapper hide-element-for-mob">
                                <figure class="feature-tab-left-image feature-image-wrapper">
                                    <div class="feature-animated-image-wrapper">
                                        <div class="feature-animated-image"><img alt="Tab Image 1" loading="lazy"
                                                                                 src="images/62daab9533d6b3c3aed0ff85_tab%20image%201.svg"
                                                                                 class="feature-tab-image"></div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-menu w-tab-menu">
                        <a data-w-tab="Create your Invoice easily"
                           class="tab-link w-inline-block w-tab-link w--current">
                            <div class="tab-link-image-wrapper">
                                <img alt="pie chart" loading="lazy" src="images/click.png" class="tab-link-image">
                            </div>
                            <div class="tab-link-text">
                                <div class="h5 _600-bold">Web sayt</div>
                                <div class="tab-para">
                                    <p class="paragraph-v-2 _500-medium">O'z biznesingizni rivojlantirmoqchimisiz?
                                        Mahsulotlar sotuvini qanday oshirishni bilmayapsizmi? Bizda bunga yechim bor!
                                        Kompaniyamiz har bir loyiha uchun alohida dasturchilar guruhini bir joyga
                                        jamlaydi.
                                        Brendingiz uchun <b>landing page</b>,<b>murakkab web sayt</b>,
                                        <b>web sayt dizayni</b>, <b>CRM va ERP tizim</b> va boshqa ko'plab qulayliklarga
                                        ega web saytlar tayyorlab beramiz. </p>
                                </div>
                            </div>
                        </a>
                        <a data-w-tab="Send a payment request and get paid" class="tab-link w-inline-block w-tab-link">
                            <div class="tab-link-image-wrapper">
                                <img alt="time line" loading="lazy" src="images/mobileappicon.png"
                                     class="tab-link-image">
                            </div>
                            <div class="tab-link-text">
                                <div class="h5 _600-bold">Mobil ilova</div>
                                <div class="tab-para">
                                    <p class="main-body-text _500-medium">Android va IOS boshqaruv tizimlari
                                        uchun mobil ilova kerakmi? Unda siz uchun GoldApps jamoasi ideal tanlov! Jamoa
                                        har qanday
                                        <b>mobil ilovaning funksional va ijodiy interfeysini</b> yaratishga qodir hamda
                                        bu sohadagi
                                        4 yillik tajribaga ega yetakchi startaperlarni jamlagan</p>
                                </div>
                            </div>
                        </a>
                        <a data-w-tab="Invoice template system" class="tab-link w-inline-block w-tab-link">
                            <div class="tab-link-image-wrapper">
                                <img alt="desktop" loading="lazy" src="images/layers.png" class="tab-link-image">
                            </div>
                            <div class="tab-link-text">
                                <div class="h5 _600-bold">UI&UX dizayn</div>
                                <div class="tab-para">
                                    <p class="main-body-text _500-medium">O'zingiz uchun boshqalarga o'xshamagan unikal
                                        web yoki mobil interfeys dizaynini izlamoqdamisiz? Unda siz uchun GoldApps
                                        jamoasi kreativ va chegirmali g'oyalarni taklif etadi! </p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="why-seo-section">
    <div class="main-container">
        <div class="why-us-flex">
            <div class="why-us-flex-left">
                <div class="why-us-caption">
                    <div class="h5 _600-bold">Nima uchun GoldApps jamoasi?</div>
                </div>
                <div class="why-us-heading"><h3 class="h2 _600-bold">Sifat, Tezlik va Unikal g'oyalar uchun!</h3></div>
                <div class="why-us-paragraph">
                    <div class="paragraph-v-1 _500-medium">Hozirda GoldApps LLCga <b>30</b>dan
                        ortiq kompaniya va tashkilotlar ishonishadi! Siz esa hali ham hamkor tanlashda o'ylanmoqdamisiz?
                    </div>
                </div>
                <div class="btn-div"><a href="#Contact" class="primary-btn w-button">Bog'lanish</a></div>
            </div>
            <div class="why-us-flex-right">
                <div class="why-us-image-wrapper"><img src="images/62daab9565feed09a03fe17e_tab%20image%202.svg"
                                                       loading="lazy" style="opacity:0"
                                                       data-w-id="6a11ae19-d03a-773f-dfa1-6fd9fcd35649" alt="Image 2"
                                                       class="why-us-image"></div>
            </div>
        </div>
    </div>
    <div id="why-seo" class="anchor-link-space"></div>
</section>
<section class="expertise-section">
    <div class="main-container w-container">
        <div class="expertise-container">
            <div class="expertise-heading"><h3 class="h2 _600-bold">Bizning xizmatlarimiz</h3></div>
            <div class="expertise-sub-para"><p class="paragraph-v-1 _500-medium">Gold Apps kompaniyasi 10dan ortiq IT
                    xizmatlar turlari bilan shug'ullanadi. Xususan kompaniyada 4 yillik tajribaga ega dasturchi, dizayner,
                    marketolog va proyekt menejerlar ishlashadi.</p></div>
            <div class="icon-box-wrapper">
                <div class="iconbox-row"><a href="#" class="icon-card w-inline-block"><img
                            src="images/consultation.png" loading="lazy" alt="Control"
                            class="box-icon"><h4 class="h5 _700-bold">IT konsultatsiya</h4>
                        <p style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Biz sizni va sizning xodimlaringizning axborot texnologiyalari
                            sohasida malakasini
                            oshirishimiz. Shu bilan birgalikda kompaniyangiz samaradorligiga ta'sir ko'rsatamiz!</p></a>
                    <a href="#" class="icon-card w-inline-block">
                        <img src="images/click.png" loading="lazy" alt="Control" class="box-icon"><h4
                            class="h5 _700-bold">Web Sayt tayyorlash</h4>
                        <p style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Har qanday darajadagi web sayt va vizit saytlari tayyorlab
                            beramiz. Loyihalar
                            tugaganidan so'ng ham dasturchilarimiz tomonidan qo'llab quvvatlash xizmatlari mavjud</p>
                    </a>
                    <a href="#" class="icon-card w-inline-block"><img
                            src="images/layers.png" loading="lazy" alt="Control"
                            class="box-icon"><h4 class="h5 _700-bold">UI&UX dizayn</h4>
                        <p style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Zamonaviy ko'rinishdagi dizayn va o'ziga xos funksionalga ega
                            responsiv mobil ilova va web sayt interfeyslarini yaratamiz! Buyurtma berishga
                            shoshiling!</p></a><a href="#" class="icon-card w-inline-block"><img
                            src="images/62dab7652259492d611381c2_Group%2094612.svg" loading="lazy" alt="Control"
                            class="box-icon"><h4 class="h5 _700-bold">SMM xizmatlari</h4>
                        <p style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Instagram, Telegram va Youtube kontentlar, xususan kopirayting,
                            smm, mobilografiya
                            va video etiting xizmatlarimiz mavjud bo'lib, barchasi tajribali ekspertlarimiz tomonidan
                            amalga oshiriladi.</p></a><a href="#" class="icon-card w-inline-block"><img
                            src="images/comp_5.png" loading="lazy" alt="Control"
                            class="box-icon1"><h4 class="h5 _700-bold">CRM va ERP tizimlari</h4>
                        <p style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Siz uchun qulay vaqtda <br>har qanday murakkablik darajasidagi
                            IT tizimlari.
                            Mustahkam va tez ishlovchi CRM tizimi sizning biznesingizga mos darajada o'rnatilib
                            beriladi.</p></a><a href="/service" class="icon-card w-inline-block"><img
                            src="images/automation.png" loading="lazy" alt="Control"
                            class="box-icon"><h4 class="h5 _700-bold">Avtomatizatsiya</h4>
                        <p style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Biznesingizning hisob-kitob ishlari, buyurtma qabul qilish kabi
                            avtomatlashtirishga
                            muxtoj bo'limlarini yuqori darajada avtomatlashtiramiz va korxona infrostrukturasini
                            optimallashtiramiz.</p>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div id="Sevices" class="anchor-link-space"></div>
</section>
<section class="team-section">
    <div class="main-container w-container">
        <div class="team-container">
            <div class="team-column">
                <div class="team-heading"><h3 class="h2 _600-bold">Bizning jamoa</h3></div>
                <div class="team-block">
                    <div class="team-block-image-wrapper"><img
                            src="images/zuxriddin.jpg" loading="lazy"
                            alt="team member image" class="team-block-image"></div>
                    <div class="team-details-wrapper">
                        <div class="team-details">
                            <div class="team-member-name">
                                <div class="h4 _600-bold">Zuxriddin Ibragimov</div>
                            </div>
                            <div class="team-member-designation">
                                <div style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium font-ravshan">Grafik dizayner. Team lead</div>
                            </div>
                        </div>
                        <a href="mailto:zuhriddin0602uz@gmail.com" class="team-contact-icon-wrapper w-inline-block">
                            <div class="team-contact-icon w-embed">
                                <svg width="19" height="15" viewBox="0 0 19 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <rect x="0.75" y="0.75" width="17.3889" height="13.5" stroke="currentColor"
                                          stroke-width="1.5"></rect>
                                    <line x1="1.47467" y1="1.35859" x2="9.97467" y2="9.85859" stroke="currentColor"
                                          stroke-width="1.5"></line>
                                    <line y1="-0.75" x2="12.0208" y2="-0.75"
                                          transform="matrix(-0.707107 0.707107 0.707107 0.707107 17.9443 1.88892)"
                                          stroke="currentColor" stroke-width="1.5"></line>
                                    <title>mail icon</title>
                                </svg>
                            </div>
                        </a></div>
                </div>
                <!--                <div class="team-block">-->
                <!--                    <div class="team-block-image-wrapper"><img-->
                <!--                            src="images/ravshan.JPG" loading="lazy"-->
                <!--                            alt="Team member Icon" class="team-block-image"></div>-->
                <!--                    <div class="team-details-wrapper">-->
                <!--                        <div class="team-details">-->
                <!--                            <div class="team-member-name">-->
                <!--                                <div class="h4 _600-bold">Ravshanbek Isakov</div>-->
                <!--                            </div>-->
                <!--                            <div class="team-member-designation">-->
                <!--                                <div style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Web dasturchi. Team lead</div>-->
                <!--                            </div>-->
                <!--                        </div>-->
                <!--                        <a href="mailto:risakov0809@gmail.com" class="team-contact-icon-wrapper w-inline-block">-->
                <!--                            <div class="team-contact-icon w-embed">-->
                <!--                                <svg width="19" height="15" viewBox="0 0 20 15" fill="none"-->
                <!--                                     xmlns="http://www.w3.org/2000/svg">-->
                <!--                                    <rect x="0.75" y="0.75" width="17.3889" height="13.5" stroke="currentColor"-->
                <!--                                          stroke-width="1.5"></rect>-->
                <!--                                    <line x1="1.47467" y1="1.35859" x2="9.97467" y2="9.85859" stroke="currentColor"-->
                <!--                                          stroke-width="1.5"></line>-->
                <!--                                    <line y1="-0.75" x2="12.0208" y2="-0.75"-->
                <!--                                          transform="matrix(-0.707107 0.707107 0.707107 0.707107 17.9443 1.88892)"-->
                <!--                                          stroke="currentColor" stroke-width="1.5"></line>-->
                <!--                                    <title>mail icon</title>-->
                <!--                                </svg>-->
                <!--                            </div>-->
                <!--                        </a></div>-->
                <!--                </div>-->
            </div>
            <div class="team-column">
                <div class="team-block">
                    <div class="team-block-image-wrapper"><img
                            src="images/62dc1b1532dfae8511d2bc5c_Rectangle%202428-1.webp" loading="lazy"
                            alt="Team member Icon" class="team-block-image"></div>
                    <div class="team-details-wrapper">
                        <div class="team-details">
                            <div class="team-member-name">
                                <div class="h4 _600-bold">Samandar Sariboyev</div>
                            </div>
                            <div class="team-member-designation">
                                <div style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">CEO. Mobile developer</div>
                            </div>
                        </div>
                        <a href="mailto:samandarsariboyev69@gmail.com" class="team-contact-icon-wrapper w-inline-block">
                            <div class="team-contact-icon w-embed">
                                <svg width="19" height="15" viewBox="0 0 19 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <rect x="0.75" y="0.75" width="17.3889" height="13.5" stroke="currentColor"
                                          stroke-width="1.5"></rect>
                                    <line x1="1.47467" y1="1.35859" x2="9.97467" y2="9.85859" stroke="currentColor"
                                          stroke-width="1.5"></line>
                                    <line y1="-0.75" x2="12.0208" y2="-0.75"
                                          transform="matrix(-0.707107 0.707107 0.707107 0.707107 17.9443 1.88892)"
                                          stroke="currentColor" stroke-width="1.5"></line>
                                    <title>mail icon</title>
                                </svg>
                            </div>
                        </a></div>
                </div>
                <div class="team-block">
                    <div class="team-block-image-wrapper"><img
                            src="images/ravshan.JPG" loading="lazy"
                            alt="Team member Icon" class="team-block-image"></div>
                    <div class="team-details-wrapper">
                        <div class="team-details">
                            <div class="team-member-name">
                                <div class="h4 _600-bold">Ravshanbek Isakov</div>
                            </div>
                            <div class="team-member-designation">
                                <div style="font-family: Satoshi, sans-serif;" class="paragraph _500-medium">Web developer. Team Lead</div>
                            </div>
                        </div>
                        <a href="mailto:example@mail.com" class="team-contact-icon-wrapper w-inline-block">
                            <div class="team-contact-icon w-embed">
                                <svg width="19" height="15" viewBox="0 0 19 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <rect x="0.75" y="0.75" width="17.3889" height="13.5" stroke="currentColor"
                                          stroke-width="1.5"></rect>
                                    <line x1="1.47467" y1="1.35859" x2="9.97467" y2="9.85859" stroke="currentColor"
                                          stroke-width="1.5"></line>
                                    <line y1="-0.75" x2="12.0208" y2="-0.75"
                                          transform="matrix(-0.707107 0.707107 0.707107 0.707107 17.9443 1.88892)"
                                          stroke="currentColor" stroke-width="1.5"></line>
                                    <title>mail icon</title>
                                </svg>
                            </div>
                        </a></div>
                </div>
            </div>
        </div>
    </div>
    <div id="Team" class="anchor-link-space"></div>
</section>
<section class="pricing-section">
    <div class="main-container pricing-plan-container">
        <div class="pricing-container">
            <div class="pricng-heading"><h4 class="h2 _600-bold">Buyurtma bermoqchimisiz?</h4></div>
            <div class="pricing-para">
                <div class="paragraph-v-1 _500-medium">Bizning xizmatlarimizning taxminiy narxlari bilan tanishib
                    chiqing!
                </div>
            </div>
            <div data-current="Tab 1" data-easing="ease" data-duration-in="300" data-duration-out="100"
                 class="pricng-tab w-tabs">
                <div class="tabs-content w-tab-content">
                    <div data-w-tab="Tab 1" class="tab-pane-tab-1 w-tab-pane w--tab-active">
                        <div class="pricing-blocks-wrapper">
                            <div class="pricng-card">
                                <div class="plan-title">
                                    <div class="h5 _600-bold">Web sayt</div>
                                </div>
                                <div class="price-details">
                                    <div><span class="dollar">$ </span><span class="pricing">299</span><span
                                            class="per-month">dan boshlanadi</span></div>
                                </div>
                                <div class="pricing-list">
                                    <div class="pricing-list-wrapper">
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Landing page</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Yangiliklar vebsayti</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Dinamik vebsaytlar</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">KMS vebsaytlar</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Brend uchun vebsaytlar</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pricing-btn"><a href="#Contact"
                                                            class="primary-btn w-button">To'liq ma'lumot</a></div>
                            </div>
                            <div class="pricng-card">
                                <div class="plan-title">
                                    <div class="h5 _600-bold">CRM va ERP tizimlar</div>
                                </div>
                                <div class="price-details more-bottom-margin">
                                    <div><span class="dollar">$ </span><span class="pricing">699</span><span
                                            class="per-month">dan boshlanadi</span></div>
                                </div>
                                <div class="pricing-list">
                                    <div class="pricing-list-wrapper">
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">CRM tizim</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Tez va sifatli</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">To'lov tizimlari bilan integratsiya
                                            </div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Avtomatlashtirish</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Internet do'konlar</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pricing-btn">
                                    <a href=#Contact" class="primary-btn w-button">To'liq ma'lumot</a>
                                </div>
                            </div>
                            <div class="pricng-card">
                                <div class="plan-title">
                                    <div class="h5 _600-bold">Mobil ilovalar</div>
                                </div>
                                <div class="price-details">
                                    <div><span class="dollar">$ </span><span class="pricing">599</span><span
                                            class="per-month">dan boshlanadi</span></div>
                                </div>
                                <div class="pricing-list">
                                    <div class="pricing-list-wrapper">
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">To'lov tizimlari bilan integratsiya
                                            </div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Har qanday qiyinchilikdagi ilova
                                            </div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">IOS operatsion tizimiga</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Funksional interfeys</div>
                                        </div>
                                        <div class="pricing-list-row">
                                            <figure class="pricing-icon-wrapper"><img alt="check mark icon"
                                                                                      loading="lazy"
                                                                                      src="images/62dd30e3a727202b54f0ec0e_checkmark%20green.svg"
                                                                                      class="check-icon"></figure>
                                            <div class="paragraph-v-2 _500-medium">Android operatsion tizimiga</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pricing-btn"><a href="#Contact"
                                                            class="primary-btn w-button">To'liq ma'lumot</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="Pricing" class="anchor-link-space"></div>
</section>
<div id="Blog" class="blog-section">
    <div class="main-container">
        <div class="blog-container">
            <div class="blog-heading"><h5 class="h2 _600-bold">So'nggi yangiliklar</h5></div>
            <div class="blog-para">
                <div class="paragraph-v-1 _500-medium">GoldApps IT outsours kompaniyasidagi so'ngi yangiliklar va
                    o'zgarishlar
                </div>
            </div>
            <div class="blog-collection-list w-dyn-list">
                <div role="list" class="blog-list w-dyn-items">
                    <div id="" role="listitem"
                         class="blog-item w-dyn-item">
                        <div class="blog-card"><a href="/post/the-art-and-science-behind-typography"
                                                  class="blog-card-image-wrapper w-inline-block"><img
                                    alt="Blog post image" loading="lazy"
                                    src="images/62e22ac860c84ce0cd5696f6_62e22a3f6c809fc073538eba_image%209858-min.webp"
                                    sizes="(max-width: 479px) 100vw, (max-width: 767px) 330px, (max-width: 991px) 43vw, (max-width: 1279px) 30vw, 330px"
                                    srcset="images/62e22ac860c84ce0cd5696f6_62e22a3f6c809fc073538eba_image%209858-min-p-500.webp 500w, images/62e22ac860c84ce0cd5696f6_62e22a3f6c809fc073538eba_image%209858-min-p-800.webp 800w, images/62e22ac860c84ce0cd5696f6_62e22a3f6c809fc073538eba_image%209858-min-p-1080.webp 1080w, images/62e22ac860c84ce0cd5696f6_62e22a3f6c809fc073538eba_image%209858-min.webp 1400w"
                                    class="blog-card-image"></a>
                            <div class="blog-card-text-wrapper">
                                <a href=#"
                                   class="blog-card-heading w-inline-block">
                                    <div>The Art and Science behind Typography</div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div id="w-node-_54eeaf05-3b67-46dc-5acb-458a1b048284-cf38ccca" role="listitem"
                         class="blog-item w-dyn-item">
                        <div class="blog-card"><a href="#"
                                                  class="blog-card-image-wrapper w-inline-block"><img
                                    alt="Blog post image" loading="lazy"
                                    src="images/62e22ae923da7520e2d34052_62e22a3fe87705e1c78229d6_image%209859-min.webp"
                                    sizes="(max-width: 479px) 100vw, (max-width: 767px) 330px, (max-width: 991px) 43vw, (max-width: 1279px) 30vw, 330px"
                                    srcset="images/62e22ae923da7520e2d34052_62e22a3fe87705e1c78229d6_image%209859-min-p-500.webp 500w, images/62e22ae923da7520e2d34052_62e22a3fe87705e1c78229d6_image%209859-min-p-800.webp 800w, images/62e22ae923da7520e2d34052_62e22a3fe87705e1c78229d6_image%209859-min-p-1080.webp 1080w, images/62e22ae923da7520e2d34052_62e22a3fe87705e1c78229d6_image%209859-min.webp 1400w"
                                    class="blog-card-image"></a>
                            <div class="blog-card-text-wrapper">
                                <a href="#"
                                   class="blog-card-heading w-inline-block">
                                    <div>When hobby, passion and profession are same</div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div role="listitem"
                         class="blog-item w-dyn-item">
                        <div class="blog-card"><a href="/post/5-tips-to-keep-your-customers-happy"
                                                  class="blog-card-image-wrapper w-inline-block"><img
                                    alt="Blog post image" loading="lazy"
                                    src="images/62e22af721100dcfd8db5075_62e22a4421100d4441db4764_image%209853-min.webp"
                                    sizes="(max-width: 479px) 100vw, (max-width: 767px) 330px, (max-width: 991px) 43vw, (max-width: 1279px) 30vw, 330px"
                                    srcset="images/62e22af721100dcfd8db5075_62e22a4421100d4441db4764_image%209853-min-p-500.webp 500w, images/62e22af721100dcfd8db5075_62e22a4421100d4441db4764_image%209853-min-p-800.webp 800w, images/62e22af721100dcfd8db5075_62e22a4421100d4441db4764_image%209853-min-p-1080.webp 1080w, images/62e22af721100dcfd8db5075_62e22a4421100d4441db4764_image%209853-min.webp 1400w"
                                    class="blog-card-image"></a>
                            <div class="blog-card-text-wrapper">
                                <a href="/post/5-tips-to-keep-your-customers-happy"
                                   class="blog-card-heading w-inline-block">
                                    <div>5 tips to keep your customers happy</div>
                                </a></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="blog-btn"><a href="/blog-page-seoflow" class="btn w-button">See all posts</a></div>
        </div>
    </div>
</div>
<section id="Contact" class="contact-section">
    <div class="main-container w-container">
        <div class="contact-container">
            <div class="contact-form-wrapper">
                <div class="contact-form-heading"><h6 class="h2 _600-bold">Biz bilan bog'lanish<br></h6></div>
                <div class="contact-para"><p class="paragraph-v-1 _500-medium">Javob kelmadimi? bizga yozing!
                        <a href="mailto:goldapps2022@gmail.com" class="contact-mail-list">goldapps2022@gmail.com</a></p>
                </div>
                <div class="form-block w-form">
                    <form id="wf-form-Home-Page-Contact-Form" name="wf-form-Home-Page-Contact-Form"
                          data-name="Home Page Contact Form" method="get" class="contact-form-block"
                          data-wf-page-id="62d564959d641a74cf38ccca"
                          data-wf-element-id="cee92b15-2722-34aa-b6fe-f7b6d531f3f3">
                        <div class="form-row fixed-height">
                            <input class="text-field _50 with-icon w-input" maxlength="256" name="Name-2"
                                   data-name="Name 2" placeholder="Ismingiz" type="text" id="Name-2" required=""><input
                                class="text-field _50 with-icon-2 w-input" maxlength="256" name="Phone-Number-2"
                                data-name="Phone Number 2" placeholder="Telefon raqamingiz" type="tel"
                                id="Phone-Number-2"
                                required=""></div>
                        <div class="form-row"><input class="text-field with-icon w-input" maxlength="256" name="Email-2"
                                                     data-name="Email 2" placeholder="Emailingiz" type="email"
                                                     id="Email-2">
                        </div>
                        <select id="field-2" name="field-2" data-name="Field 2" class="text-field w-select">
                            <option value="">Xizmat turini tanlang</option>
                            <option value="First">Mobil ilova</option>
                            <option value="Second">Web sayt</option>
                            <option value="Third">Telegram bot</option>
                            <option value="Third">Web dizayn</option>
                            <option value="Third">CRM tizim</option>
                            <option value="Third">Grafik dizayn va video montaj</option>
                        </select>
                        <div class="form-row"><textarea placeholder="Xabaringiz" maxlength="5000" id="Message-2"
                                                        name="Message-2" data-name="Message 2"
                                                        class="message-box w-input"></textarea></div>
                        <div class="submit-btn-wrapper"><input type="submit" data-wait="Iltimos kuting..."
                                                               class="submit-btn-green w-button"
                                                               value="Xabarni yuborish"></div>
                    </form>
                    <div class="w-form-done">
                        <div>Xabaringiz yuborildi. Rahmat!</div>
                    </div>
                    <div class="w-form-fail">
                        <div>Oops! Xabar uzatishda xatolik!</div>
                    </div>
                </div>
            </div>
            <div class="contact-blocks-wrapper">
                <div class="contact-block"><img src="images/62dd44d9a3dc2c6e578e1c25_Phone%20Ringing%2002.svg"
                                                loading="lazy" alt="" class="contact-block-icon">
                    <div class="contact-block-text-wrapper">
                        <div class="contact-block-titile"><h4 class="h5 _700-bold">Bog'lanish uchun kontaktlar</h4>
                        </div>
                        <a href="tel:1800-123-1234" class="contact-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">+998(99) 566 71 55</div>
                        </a><a href="tel:+16221233000" class="contact-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">+998(91) 024 80 24</div>
                        </a></div>
                </div>
                <div class="contact-block"><img src="images/62dd452df9ac897952e1e592_Message.svg" loading="lazy" alt=""
                                                class="contact-block-icon">
                    <div class="contact-block-text-wrapper">
                        <div class="contact-block-titile"><h4 class="h5 _700-bold">Email</h4></div>
                        <a href="mailto:goldapps2022@gmail.com" class="contact-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">goldapps2022@gmail.com</div>
                        </a></div>
                </div>
            </div>
        </div>
    </div>
</section>
<div id="Footer" class="footer-section">
    <div class="main-container">
        <div class="footer-container-2">
            <div class="footer-column-wrapper">
                <div class="footer-columns">
                    <div class="footer-column-title">
                        <div class="h5 _600-bold">Yo'naltirish</div>
                    </div>
                    <div class="footer-column-text-wrapper _2-column-layout"><a
                            href="#Home" class="footer-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">Bosh sahifa</div>
                        </a><a href="#why-seo" class="footer-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">Biz haqimizda</div>
                        </a><a href="#Sevices" class="footer-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">Xizmatlar</div>
                        </a><a href="#Team" class="footer-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">Jamoa</div>
                        </a><a href="#Pricing" class="footer-link w-inline-block">
                            <div class="paragraph-v-2 _500-medium">Narxlar</div>
                        </a></div>
                </div>
                <div class="footer-columns">
                    <div class="footer-column-title">
                        <div class="h5 _600-bold">Ma'lumot uchun</div>
                    </div>
                    <div class="footer-column-text-wrapper">
                        <div class="footer-text">
                            <div class="day-title">
                                <div class="paragraph-v-2 _500-medium">Ish kunlari</div>
                            </div>
                            <div class="time-wrapper">
                                <div class="paragraph-v-2 _500-medium">9:00 - 20:00</div>
                            </div>
                        </div>
                        <div class="footer-text">
                            <div class="day-title">
                                <div class="paragraph-v-2 _500-medium">Shanba</div>
                            </div>
                            <div class="time-wrapper">
                                <div class="paragraph-v-2 _500-medium">10:00 - 18:00</div>
                            </div>
                        </div>
                        <div class="footer-text">
                            <div class="day-title">
                                <div class="paragraph-v-2 _500-medium">Yakshanba</div>
                            </div>
                            <div class="time-wrapper">
                                <div class="paragraph-v-2 _500-medium">Dam olish</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-columns">
                    <div class="footer-column-title">
                        <div class="h5 _600-bold">Qo'ng'iroq</div>
                    </div>
                    <div class="footer-column-text-wrapper">
                        <div class="footer-btn-wrapper"><a href="tel: +998(91) 024 80 24"
                                                           class="secondary-btn w-inline-block"><img
                                    src="images/62dd484f920df34fa7f166ef_filled%20phone.svg" loading="lazy" alt=""
                                    class="btn-icon">
                                <div>+998(91) 024 80 24</div>
                            </a></div>
                        <div class="footer-btn-wrapper"><a href="#Contact"
                                                           class="primary-btn hover-white w-button">Xabar qoldirish</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-wrapper">
                <div class="webflow-branding">
                    <div class="copyright-text-wrapper">
                        <div class="copyright-text">
                            <div>Copyright © 2022 GoldApps LLC. Barcha huquqlar himoyalangan</div>
                        </div>
                        <a href="#" class="copyright-link w-inline-block">
                            <div>Changelog</div>
                        </a><a href="#" class="copyright-link w-inline-block">
                            <div>Litsenziya ma'lumoti</div>
                        </a></div>
                    <div><a href="#" target="_blank" class="webflow-link">GoldApps LLC</a> tomonidan ishlab chiqildi
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="scroll-to-top"><a href="#Top" class="scroll-to-top-link w-inline-block"><img
            src="images/62d564959d641aff6d38cd86_uparrow.svg" loading="lazy" alt="up arrow" class="up-arrow-image"></a>
</div>
<script src="js/jquery-3.5.1.min.dc5e7f18c8.js" type="text/javascript" crossorigin="anonymous"></script>
<script src="js/webflow.25bbbfe25.js" type="text/javascript"></script>
</body>
</html>
<?php /**PATH W:\domains\goldapps\resources\views/user/index.blade.php ENDPATH**/ ?>